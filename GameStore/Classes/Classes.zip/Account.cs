﻿using GameStore.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameStore.Classes
{
    internal class Account
    {
        Person person;
        public string Username { get; private set; }
        public string Password { get; private set; }
        List<Game> games;
        List<Account> friends;
        List<Transaction> transactions;
        float money;
        IAccount store;

        public Account(string email, string username, string password, IAccount store, string firstName = "", string lastName = "")
        {
            this.Username = username;
            this.Password = password;
            this.store = store;
            games = new List<Game>();
            friends = new List<Account>();
            transactions = new List<Transaction>();
            money = 0;
            person = new Person(firstName, lastName, email);
        }

        internal void ShowCLI()
        {
            Console.WriteLine("You have logged in account!");
            Thread.Sleep(1000);
            while (true)
            {
                Console.WriteLine("Choose action:");
                Console.WriteLine("1. Buy game");
                Console.WriteLine("2. Show my games");
                Console.WriteLine("3. Show games in store");
                Console.WriteLine("4. Add money");
                Console.WriteLine("5. Play game");
                Console.WriteLine("[any]. Logout");

                var option = Console.ReadKey();
                Console.WriteLine();

                Console.Clear();
                switch (option.Key)
                {
                    case ConsoleKey.D1:
                        if (!BuyGame())
                            Console.WriteLine("Game wasn't added due to Error!");
                        break;

                    case ConsoleKey.D2:
                        ShowPurchasedGames();
                        break;

                    case ConsoleKey.D3:
                        store.ShowStoreGames();
                        break;

                    case ConsoleKey.D4:
                        AddMoney();
                        Thread.Sleep(1000);
                        break;

                    case ConsoleKey.D5:
                        PlayGames();
                        break;

                    default:
                        return;
                }
            }
        }

        private void PlayGames()
        {
            ShowPurchasedGames();
            if (games.Count == 0)
                return;
            Console.Write("Choose game you want to play: ");
            int index;
            if (!int.TryParse(Console.ReadLine(), out index))
                return;
            else
                games[index].Play();
        }

        public bool BuyGame() 
        {
            store.ShowStoreGames();
            Console.WriteLine("Write down ID of a game: "); 
            int index;
            if (!int.TryParse(Console.ReadLine(), out index))
                return false;
            Game? game = store.BuyGame(index, money);
            if(game == null)
                return false;

            if (games.Contains(game))
            {
                Console.WriteLine("You've already purchased this game!");
                return false;
            }

            Console.Clear();
            Transaction tr = new Transaction(DateTime.Now, game.Cost);
            Console.WriteLine(game);
            tr.ShowInfo();
            transactions.Add(tr);

            money -= tr.Cost;

            games.Add(game);

            return true;
        }
        public void showFriendsList() 
        { 
            for(int i = 0; i < friends.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i+1, friends[i]);
            }
        }
        public void ShowPurchasedGames() 
        {
            if(games.Count == 0)
                Console.WriteLine("You have no games!");
            else
                for(int i = 0; i < games.Count; i++)
                    Console.WriteLine("{0}: {1}", i, games[i]);
        }
        public void AddMoney() 
        {
            Console.Write("How much do you want to add?: ");
            float money;

            if(!float.TryParse(Console.ReadLine(), out money))
                Console.WriteLine("Error!");
            else
            {
                Console.WriteLine("Money added successfully!");
                this.money += money;
            }
        }
        public void addNewFriend(Account friend) { friends.Add(friend); }
        public void removeFriend(Account friend) { friends.Remove(friend); }

        public override string ToString()
        {
            return String.Format("{0}", Username);
        }
    }
}
