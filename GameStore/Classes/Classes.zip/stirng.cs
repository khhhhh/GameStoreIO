﻿namespace GameStore.Classes
{
    internal class stirng
    {
    }
}